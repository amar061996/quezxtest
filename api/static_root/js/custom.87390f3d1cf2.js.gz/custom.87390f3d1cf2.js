$(document).ready(function(){

	$("#add").click(function(){
		$("#addForm").slideToggle("1000");
});

})


